<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.7.2" name="Plants" tilewidth="8" tileheight="8" tilecount="6" columns="2">
 <image source="Plants.png" width="16" height="24"/>
</tileset>
